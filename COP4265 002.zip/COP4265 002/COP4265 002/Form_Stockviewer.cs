﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using static System.Windows.Forms.AxHost;

namespace COP4265_002
{
    public partial class Form_Stockviewer : Form
    {
        // List to hold all the candlesticks read from the file
        List<Candlestick> listOfCandlesticks = new List<Candlestick>();
        // BindingList to store candlesticks for data binding
        BindingList<Candlestick> BindinglistOfCandlesticks = new BindingList<Candlestick>();

        public Form_Stockviewer()
        {
            InitializeComponent();
        }

        private void button_loadStock(object sender, EventArgs e)
        {
            // Show the file dialog to select a stock file
            openFileDialog_stockPicker.ShowDialog();
        }

        private void openFileDialog_StockChooser_Fileok(object sender, CancelEventArgs e)
        {
            //Get the selected file name
            string filename = openFileDialog_stockPicker.FileName;
            // Set the title of the form to the selected filename
            this.Text = filename;
            //Call Read the file, filter candlesticks, display candlesticks, normalize the chart, and display the chart
            goReadFile();
            filtercandlesticks();
            displayCandlesticks();
            normalizechart();
            displayChart();
        }

        /// <summary>
        /// Read the selected file and populate the listOfCandlesticks
        /// Does not return anything
        /// </summary>
        private void goReadFile()
        {
            // Call function to read the selected file and output it to a listofcandlesticks
            listOfCandlesticks = goReadFile(openFileDialog_stockPicker.FileName);
        }

        /// <summary>
        /// Read the file and convert data into candlesticks
        /// This Function will convert the data input from a csv file into candlesticks
        /// </summary>
        /// <param name="filename">
        /// It takes in a string that holds the file name of the file to be read 
        /// </param>
        /// <returns>
        /// It returns a list of candlesticks read from the selected file
        /// </returns>
        private List<Candlestick> goReadFile(string filename)
        {
            //const string referencestring = "Date,Open,High,Low,Close,Adj Close,Volume";
            List<Candlestick> resultList = new List<Candlestick>(1024);

            //Pass the file path and filename to the Stream reader constructor 
            using (StreamReader sr = new StreamReader(openFileDialog_stockPicker.FileName))
            {
                // Read the header line
                string line = sr.ReadLine(); 
                //continue to read until you reach end of file
                while ((line = sr.ReadLine()) != null)
                {
                    //Read the next line
                    //This is where we need to instantiate the candlestick represented by the string  
                    Candlestick cs = new Candlestick(line); // Create candlestick object from the line
                    resultList.Add(cs); // Add candlestick to the list
                }
            }
            return resultList; // Return list of candlesticks
        }

        /// <summary>
        /// Filter candlesticks based on start and end date
        /// Stores only the candlesticks we want from the read data
        /// </summary>
        /// <param name="Candlestickslist">
        /// It takes in a list of candlesticks that was read from the selected file 
        /// </param>
        /// <param name="startDate">
        /// Takes in the value of the prefered start date for the filter
        /// </param>
        /// <param name="endDate">
        /// Takes in the value of the prefered end date for the filter 
        /// </param>
        /// <returns> It returns a list of filtered candlesticks from the prefered startdate to the enddate</returns>
        private List<Candlestick> filterCandlesticks(List<Candlestick> Candlestickslist, DateTime startDate, DateTime endDate)
        {
            //Create a list of candlesticks 
            List<Candlestick> selectedCandlesticks = new List<Candlestick>();
            // Loop over each candlestick in the listofcandlesticks
            foreach (Candlestick cs in Candlestickslist)
            {
                //If we have not reached the start date yet, go to the next candlestick
                if (cs.date < startDate)
                    continue;
                //If we have passed the ending date, we are done
                if (cs.date > endDate)
                    break;
                //At this point we are in the right range so we just add to the bounding list
                selectedCandlesticks.Add(cs);
            }
            return selectedCandlesticks; // Return filtered candlesticks
        }

        /// <summary>
        /// This function is the helper function for the filterCandlesticks function.
        /// It calls the parent function which return a list of candlesticks, with the filter range values from the datetime picker and a list of all the candlestick.
        /// It then stores the values of the filteredList into a BindingList.
        /// </summary>
        private void filtercandlesticks()
        {
            //Start date values from the datetime picker 
            DateTime startDate = dateTimePicker_startDate.Value.Date;
            //End date values from the datetime picker
            DateTime endDate = dateTimePicker_endDate.Value.Date;
            //Create a new list to store the filtered cnadlesticks from the parent function
            List<Candlestick> filteredlist = filterCandlesticks(listOfCandlesticks, startDate, endDate);
            //CLear previous values in the BindingList
            BindinglistOfCandlesticks.Clear();
            //Copy values of the filtered list into the BindingList
            BindinglistOfCandlesticks = new BindingList<Candlestick>(filteredlist);
        }

        /// <summary>
        /// Normalizes chart properties by setting minimum and maximum values of chart area and sets the Y value members so it displays properly
        /// </summary>
        private void normalizechart()
        {
            //Check if the BindingList is not null or empty to continue
            if (BindinglistOfCandlesticks != null && BindinglistOfCandlesticks.Count > 0)
            {
                //Set series Y value member
                chart_Candlesticks.Series["OHLC"].YValueMembers = "high, low, open, close";

                //Set chart area properties 
                chart_Candlesticks.ChartAreas["ChartArea_OHLC"].AxisY.Minimum = 
                    0.98 * (double)Math.Floor((BindinglistOfCandlesticks.Min(c => c.low)));// Adjust minimum for better visulization 
                chart_Candlesticks.ChartAreas["ChartArea_OHLC"].AxisY.Maximum = 
                    1.02 * (double)Math.Ceiling(BindinglistOfCandlesticks.Max(c => c.high));// Adjust minimum for better visulization
            }
        }

        /// <summary>
        /// Display the chart with normalized axis by giving it an accurate list as its datasource and binding the data to the chart 
        /// </summary>
        private void displayChart()
        {
            //Now bind the chart to the bindindList of candlesticks
            chart_Candlesticks.DataSource = BindinglistOfCandlesticks;
            //Make the databinding availiable to the chart
            chart_Candlesticks.DataBind();
        }

        /// <summary>
        /// Display filtered candlesticks in DataGridView
        /// The the data grid view gets the correct list as a datasource 
        /// </summary>
        private void displayCandlesticks()
        {
            //Create a new Bindinglist to store the filtered candlesticks to be displayed
            BindingList<Candlestick> Boundlist = new BindingList<Candlestick>(BindinglistOfCandlesticks);
            //Bind the DataGridview to the updated BindingList
            dataGridView_candlesticks_view.DataSource = Boundlist;
        }

        /// <summary>
        /// Update candlesticks data when new start or end data have been selected 
        /// Calls the required functions in the right order 
        /// </summary>
        private void update()
        {
            //This function will return the candlesticks that are in the desired date range
            filtercandlesticks();
            //Display updated data to the datagrid view
            displayCandlesticks();
            //Setting minimum and maximum values of chart area and sets the Y value members so it displays properly
            normalizechart();
            //Display updated data to the chart
            displayChart();
        }

        private void button_Update(object sender, EventArgs e)
        {
            update(); // Call update function when the button is clicked
        }
    }
}
